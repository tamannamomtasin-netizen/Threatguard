#ifndef PASSWORDMODULE_H
#define PASSWORDMODULE_H

#include <string>

using String = std::string;

class PasswordModule {
public:
    // Validate password strength
    static bool validatePassword(const String& password);

    // Hash password (simple custom hash)
    static String hashPassword(const String& password);

    // Verify password against hash
    static bool verifyPassword(const String& password, const String& hash);

private:
    // Helper methods for password validation
    static bool hasUppercase(const String& password);
    static bool hasLowercase(const String& password);
    static bool hasDigit(const String& password);
    static bool hasSpecialCharacter(const String& password);
    static bool hasMinimumLength(const String& password);
};

#endif
