#include "User.h"

User::User() : username(""), hashedPassword(""), failedAttempts(0), isLocked(false) {}

User::User(const std::string& username, const std::string& hashedPassword)
    : username(username), hashedPassword(hashedPassword), failedAttempts(0), isLocked(false) {}

std::string User::getUsername() const {
    return username;
}

std::string User::getHashedPassword() const {
    return hashedPassword;
}

int User::getFailedAttempts() const {
    return failedAttempts;
}

bool User::getIsLocked() const {
    return isLocked;
}

void User::setUsername(const std::string& username) {
    this->username = username;
}

void User::setHashedPassword(const std::string& hashedPassword) {
    this->hashedPassword = hashedPassword;
}

void User::setFailedAttempts(int attempts) {
    this->failedAttempts = attempts;
}

void User::setIsLocked(bool locked) {
    this->isLocked = locked;
}

void User::incrementFailedAttempts() {
    failedAttempts++;
    if (failedAttempts >= 3) {
        lockAccount();
    }
}

void User::resetFailedAttempts() {
    failedAttempts = 0;
}

void User::lockAccount() {
    isLocked = true;
}

void User::unlockAccount() {
    isLocked = false;
    failedAttempts = 0;
}

bool User::isAccountLocked() const {
    return isLocked;
}
