#ifndef USER_H
#define USER_H

#include <string>

using String = std::string;

class User {
private:
    String username;
    String hashedPassword;
    int failedAttempts;
    bool isLocked;

public:
    User();
    User(const String& username, const String& hashedPassword);

    // Getters
    String getUsername() const;
    String getHashedPassword() const;
    int getFailedAttempts() const;
    bool getIsLocked() const;

    // Setters
    void setUsername(const String& username);
    void setHashedPassword(const String& hashedPassword);
    void setFailedAttempts(int attempts);
    void setIsLocked(bool locked);

    // Methods
    void incrementFailedAttempts();
    void resetFailedAttempts();
    void lockAccount();
    void unlockAccount();
    bool isAccountLocked() const;
};

#endif
