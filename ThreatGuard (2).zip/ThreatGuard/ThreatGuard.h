#ifndef THREATGUARD_H
#define THREATGUARD_H

#include <vector>
#include <string>
#include "User.h"
#include "Logger.h"

using String = std::string;
using UserList = std::vector<User>;

class ThreatGuard {
private:
    UserList users;
    Logger logger;
    String currentUsername;

public:
    ThreatGuard();
    ~ThreatGuard();

    // Main menu
    void showMainMenu();

    // User management
    bool registerUser(const String& username, const String& password);
    bool loginUser(const String& username, const String& password);
    void logoutUser();

    // User operations
    void showUserDashboard();
    void changePassword(const String& username, const String& oldPassword, const String& newPassword);
    void viewUserLogs(const String& username);

    // Admin operations
    void showAdminMenu();
    void viewAllLogs();
    void viewAllUsers();
    void unlockUserAccount(const String& username);

    // Helper methods
    User* findUser(const String& username);
    bool isUserExists(const String& username);
    bool isPasswordValid(const String& password);
    void displayPasswordRequirements();
    User* getCurrentUser();

private:
    // UI helpers
    void clearScreen() const;
    void waitForEnter() const;
    void displayHeader(const String& title) const;
    void displayBanner(const String& title, const String& subtitle) const;
    void displaySection(const String& title) const;
    void displayStatus(const String& message, const String& style = "INFO") const;
    void printMenu(const String& title, const std::vector<String>& options, const String& subtitle = "") const;
    int readIntChoice(const String& prompt) const;
    String readTextInput(const String& prompt) const;
};

#endif
