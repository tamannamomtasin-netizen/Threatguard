#ifndef LOGGER_H
#define LOGGER_H

#include <string>
#include <vector>
#include <ctime>

using String = std::string;

struct LogEntry {
    String timestamp;
    String eventType;
    String username;
    String details;
};

class Logger {
private:
    std::vector<LogEntry> logs;
    static const int MAX_LOG_ENTRIES = 1000;

public:
    Logger();

    // Log different types of events
    void logRegistration(const String& username);
    void logLogin(const String& username, bool success);
    void logFailedAttempt(const String& username, int attempts);
    void logAccountLocked(const String& username);
    void logAccountUnlocked(const String& username);
    void logBruteForceAlert(const String& username);
    void logPasswordChange(const String& username);

    // Display logs
    void displayAllLogs() const;
    void displayUserLogs(const String& username) const;
    void displayRecentLogs(int count) const;

    // Get current timestamp
    String getCurrentTimestamp() const;

private:
    void addLog(const String& eventType, const String& username, const String& details);
};

#endif
