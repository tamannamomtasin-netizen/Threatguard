#include "PasswordHasher.h"
#include <sstream>
#include <iomanip>
#include <random>
#include <cstring>
#include <cstdint>
#include <vector>

namespace {
    inline uint32_t rotateRight(uint32_t value, unsigned int bits) {
        return (value >> bits) | (value << (32 - bits));
    }

    inline uint32_t choose(uint32_t e, uint32_t f, uint32_t g) {
        return (e & f) ^ (~e & g);
    }

    inline uint32_t majority(uint32_t a, uint32_t b, uint32_t c) {
        return (a & b) ^ (a & c) ^ (b & c);
    }

    inline uint32_t sigma0(uint32_t x) {
        return rotateRight(x, 2) ^ rotateRight(x, 13) ^ rotateRight(x, 22);
    }

    inline uint32_t sigma1(uint32_t x) {
        return rotateRight(x, 6) ^ rotateRight(x, 11) ^ rotateRight(x, 25);
    }

    inline uint32_t delta0(uint32_t x) {
        return rotateRight(x, 7) ^ rotateRight(x, 18) ^ (x >> 3);
    }

    inline uint32_t delta1(uint32_t x) {
        return rotateRight(x, 17) ^ rotateRight(x, 19) ^ (x >> 10);
    }

    const uint32_t k[64] = {
        0x428a2f98u, 0x71374491u, 0xb5c0fbcfu, 0xe9b5dba5u,
        0x3956c25bu, 0x59f111f1u, 0x923f82a4u, 0xab1c5ed5u,
        0xd807aa98u, 0x12835b01u, 0x243185beu, 0x550c7dc3u,
        0x72be5d74u, 0x80deb1feu, 0x9bdc06a7u, 0xc19bf174u,
        0xe49b69c1u, 0xefbe4786u, 0x0fc19dc6u, 0x240ca1ccu,
        0x2de92c6fu, 0x4a7484aau, 0x5cb0a9dcu, 0x76f988dau,
        0x983e5152u, 0xa831c66du, 0xb00327c8u, 0xbf597fc7u,
        0xc6e00bf3u, 0xd5a79147u, 0x06ca6351u, 0x14292967u,
        0x27b70a85u, 0x2e1b2138u, 0x4d2c6dfcu, 0x53380d13u,
        0x650a7354u, 0x766a0abbu, 0x81c2c92eu, 0x92722c85u,
        0xa2bfe8a1u, 0xa81a664bu, 0xc24b8b70u, 0xc76c51a3u,
        0xd192e819u, 0xd6990624u, 0xf40e3585u, 0x106aa070u,
        0x19a4c116u, 0x1e376c08u, 0x2748774cu, 0x34b0bcb5u,
        0x391c0cb3u, 0x4ed8aa4au, 0x5b9cca4fu, 0x682e6ff3u,
        0x748f82eeu, 0x78a5636fu, 0x84c87814u, 0x8cc70208u,
        0x90befffau, 0xa4506cebu, 0xbef9a3f7u, 0xc67178f2u
    };

    std::string toHexString(const unsigned char* data, size_t length) {
        std::ostringstream ss;
        ss << std::hex << std::setfill('0');
        for (size_t i = 0; i < length; ++i) {
            ss << std::setw(2) << static_cast<unsigned int>(data[i]);
        }
        return ss.str();
    }
}

std::string PasswordHasher::createSalt() {
    std::random_device rd;
    std::mt19937_64 gen(rd());
    std::uniform_int_distribution<uint64_t> dist(0, UINT64_MAX);

    std::ostringstream ss;
    ss << std::hex << std::setw(16) << std::setfill('0') << dist(gen);
    ss << std::hex << std::setw(16) << std::setfill('0') << dist(gen);
    return ss.str();
}

std::string PasswordHasher::sha256(const std::string& input) {
    uint64_t bitlen = static_cast<uint64_t>(input.size()) * 8;
    std::vector<unsigned char> data(input.begin(), input.end());
    data.push_back(0x80);
    while ((data.size() % 64) != 56) {
        data.push_back(0x00);
    }

    for (int i = 7; i >= 0; --i) {
        data.push_back(static_cast<unsigned char>((bitlen >> (i * 8)) & 0xFF));
    }

    uint32_t h[8] = {
        0x6a09e667u, 0xbb67ae85u, 0x3c6ef372u, 0xa54ff53au,
        0x510e527fu, 0x9b05688cu, 0x1f83d9abu, 0x5be0cd19u
    };

    for (size_t chunkStart = 0; chunkStart < data.size(); chunkStart += 64) {
        uint32_t w[64];
        for (int i = 0; i < 16; ++i) {
            size_t offset = chunkStart + i * 4;
            w[i] = (static_cast<uint32_t>(data[offset]) << 24)
                 | (static_cast<uint32_t>(data[offset + 1]) << 16)
                 | (static_cast<uint32_t>(data[offset + 2]) << 8)
                 | static_cast<uint32_t>(data[offset + 3]);
        }
        for (int i = 16; i < 64; ++i) {
            w[i] = delta1(w[i - 2]) + w[i - 7] + delta0(w[i - 15]) + w[i - 16];
        }

        uint32_t a = h[0];
        uint32_t b = h[1];
        uint32_t c = h[2];
        uint32_t d = h[3];
        uint32_t e = h[4];
        uint32_t f = h[5];
        uint32_t g = h[6];
        uint32_t hh = h[7];

        for (int i = 0; i < 64; ++i) {
            uint32_t t1 = hh + sigma1(e) + choose(e, f, g) + k[i] + w[i];
            uint32_t t2 = sigma0(a) + majority(a, b, c);
            hh = g;
            g = f;
            f = e;
            e = d + t1;
            d = c;
            c = b;
            b = a;
            a = t1 + t2;
        }

        h[0] += a;
        h[1] += b;
        h[2] += c;
        h[3] += d;
        h[4] += e;
        h[5] += f;
        h[6] += g;
        h[7] += hh;
    }

    unsigned char hash[32];
    for (int i = 0; i < 8; ++i) {
        hash[i * 4] = static_cast<unsigned char>((h[i] >> 24) & 0xFF);
        hash[i * 4 + 1] = static_cast<unsigned char>((h[i] >> 16) & 0xFF);
        hash[i * 4 + 2] = static_cast<unsigned char>((h[i] >> 8) & 0xFF);
        hash[i * 4 + 3] = static_cast<unsigned char>(h[i] & 0xFF);
    }

    return toHexString(hash, sizeof(hash));
}

std::string PasswordHasher::hashPassword(const std::string& password, const std::string& salt) {
    return sha256(password + salt);
}

bool PasswordHasher::verifyPassword(const std::string& password, const std::string& salt, const std::string& hash) {
    return hashPassword(password, salt) == hash;
}
