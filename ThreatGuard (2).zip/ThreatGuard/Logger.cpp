#include "Logger.h"
#include <iostream>
#include <iomanip>
#include <sstream>
#include <chrono>

Logger::Logger() {
    logs.reserve(MAX_LOG_ENTRIES);
}

std::string Logger::getCurrentTimestamp() const {
    auto now = std::chrono::system_clock::now();
    auto time_t = std::chrono::system_clock::to_time_t(now);
    std::stringstream ss;
    ss << std::put_time(std::localtime(&time_t), "%Y-%m-%d %H:%M:%S");
    return ss.str();
}

void Logger::addLog(const std::string& eventType, const std::string& username, const std::string& details) {
    LogEntry entry;
    entry.timestamp = getCurrentTimestamp();
    entry.eventType = eventType;
    entry.username = username;
    entry.details = details;

    logs.push_back(entry);

    // Keep only MAX_LOG_ENTRIES
    if (logs.size() > MAX_LOG_ENTRIES) {
        logs.erase(logs.begin());
    }
}

void Logger::logRegistration(const std::string& username) {
    addLog("REGISTRATION", username, "User registered successfully");
}

void Logger::logLogin(const std::string& username, bool success) {
    if (success) {
        addLog("LOGIN_SUCCESS", username, "User logged in successfully");
    } else {
        addLog("LOGIN_FAILED", username, "Login attempt failed");
    }
}

void Logger::logFailedAttempt(const std::string& username, int attempts) {
    addLog("FAILED_ATTEMPT", username, "Failed login attempt #" + std::to_string(attempts));
}

void Logger::logAccountLocked(const std::string& username) {
    addLog("ACCOUNT_LOCKED", username, "Account locked due to multiple failed attempts");
}

void Logger::logAccountUnlocked(const std::string& username) {
    addLog("ACCOUNT_UNLOCKED", username, "Account unlocked");
}

void Logger::logBruteForceAlert(const std::string& username) {
    addLog("BRUTE_FORCE_ALERT", username, "*** BRUTE FORCE ATTACK DETECTED ***");
}

void Logger::logPasswordChange(const std::string& username) {
    addLog("PASSWORD_CHANGE", username, "Password changed successfully");
}

void Logger::displayAllLogs() const {
    std::cout << "\n========== SYSTEM LOGS ==========\n";
    if (logs.empty()) {
        std::cout << "No logs available.\n";
        return;
    }

    std::cout << "Timestamp\t\tEvent Type\tUsername\tDetails\n";
    std::cout << "--------------------------------------------------------\n";
    for (const auto& log : logs) {
        std::cout << log.timestamp << "\t"
                  << log.eventType << "\t"
                  << log.username << "\t"
                  << log.details << "\n";
    }
}

void Logger::displayUserLogs(const std::string& username) const {
    std::cout << "\n========== LOGS FOR USER: " << username << " ==========\n";
    bool found = false;

    for (const auto& log : logs) {
        if (log.username == username) {
            std::cout << log.timestamp << "\t"
                      << log.eventType << "\t"
                      << log.details << "\n";
            found = true;
        }
    }

    if (!found) {
        std::cout << "No logs found for user: " << username << "\n";
    }
}

void Logger::displayRecentLogs(int count) const {
    std::cout << "\n========== RECENT " << count << " LOGS ==========\n";
    int start = logs.size() > count ? logs.size() - count : 0;

    for (size_t i = start; i < logs.size(); ++i) {
        const auto& log = logs[i];
        std::cout << log.timestamp << "\t"
                  << log.eventType << "\t"
                  << log.username << "\t"
                  << log.details << "\n";
    }
}
