#include "PasswordModule.h"
#include <cctype>
#include <algorithm>

bool PasswordModule::validatePassword(const std::string& password) {
    // Check minimum length (8 characters)
    if (!hasMinimumLength(password)) {
        return false;
    }

    // Check for uppercase letter
    if (!hasUppercase(password)) {
        return false;
    }

    // Check for lowercase letter
    if (!hasLowercase(password)) {
        return false;
    }

    // Check for digit
    if (!hasDigit(password)) {
        return false;
    }

    // Check for special character
    if (!hasSpecialCharacter(password)) {
        return false;
    }

    return true;
}

std::string PasswordModule::hashPassword(const std::string& password) {
    // Simple custom hash for demonstration
    // In production, use proper cryptographic hashing
    unsigned long hash = 5381;
    for (char c : password) {
        hash = ((hash << 5) + hash) + c; // hash * 33 + c
    }

    // Convert to hex string
    std::string hexHash;
    char buffer[17];
    snprintf(buffer, sizeof(buffer), "%016lx", hash);
    hexHash = buffer;

    // Add salt (simple for demonstration)
    std::string salt = "ThreatGuard_SALT_2026";
    std::string saltedHash = hexHash + salt;

    // Second hash for extra security
    unsigned long finalHash = 5381;
    for (char c : saltedHash) {
        finalHash = ((finalHash << 5) + finalHash) + c;
    }

    char finalBuffer[17];
    snprintf(finalBuffer, sizeof(finalBuffer), "%016lx", finalHash);
    return std::string(finalBuffer);
}

bool PasswordModule::verifyPassword(const std::string& password, const std::string& hash) {
    std::string computedHash = hashPassword(password);
    return computedHash == hash;
}

bool PasswordModule::hasUppercase(const std::string& password) {
    return std::any_of(password.begin(), password.end(), ::isupper);
}

bool PasswordModule::hasLowercase(const std::string& password) {
    return std::any_of(password.begin(), password.end(), ::islower);
}

bool PasswordModule::hasDigit(const std::string& password) {
    return std::any_of(password.begin(), password.end(), ::isdigit);
}

bool PasswordModule::hasSpecialCharacter(const std::string& password) {
    return std::any_of(password.begin(), password.end(), [](char c) {
        return !std::isalnum(c);
    });
}

bool PasswordModule::hasMinimumLength(const std::string& password) {
    return password.length() >= 8;
}
