#ifndef PASSWORDHASHER_H
#define PASSWORDHASHER_H

#include <string>

class PasswordHasher {
public:
    static std::string createSalt();
    static std::string hashPassword(const std::string& password, const std::string& salt);
    static bool verifyPassword(const std::string& password, const std::string& salt, const std::string& hash);
    static std::string sha256(const std::string& input);
};

#endif // PASSWORDHASHER_H
