#include "ThreatGuard.h"
#include "PasswordModule.h"
#include <iostream>
#include <limits>
#include <algorithm>
#include <cstdlib>

ThreatGuard::ThreatGuard() : currentUsername("") {
    // Initialize with demo users (silently)
    String hashedPass1 = PasswordModule::hashPassword("Uftb@123");
    String hashedPass2 = PasswordModule::hashPassword("Uftb@123");

    User adminUser("admin", hashedPass1);
    User regularUser("user", hashedPass2);

    users.push_back(adminUser);
    users.push_back(regularUser);

    logger.logRegistration("admin");
    logger.logRegistration("user");
}

ThreatGuard::~ThreatGuard() {
    // Cleanup
}

void ThreatGuard::clearScreen() const {
    #ifdef _WIN32
        system("cls");
    #else
        system("clear");
    #endif
}

void ThreatGuard::waitForEnter() const {
    std::cout << "\nPress Enter to continue...";
    std::cout << std::flush;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
}

int ThreatGuard::readIntChoice(const String& prompt) const {
    std::cout << prompt << std::flush;
    std::cin.clear();
    String input;
    std::getline(std::cin, input);
    std::cout << std::endl;

    try {
        return std::stoi(input);
    } catch (...) {
        return -1;
    }
}

String ThreatGuard::readTextInput(const String& prompt) const {
    std::cout << prompt << std::flush;
    std::cin.clear();
    String input;
    std::getline(std::cin, input);
    std::cout << std::endl;
    return input;
}

void ThreatGuard::displayHeader(const String& title) const {
    clearScreen();
    std::cout << "THREAT GUARD SYSTEM\n";
    std::cout << "========================================\n";
    std::cout << "    " << title << "\n";
    std::cout << "========================================\n";
}

void ThreatGuard::displayBanner(const String& title, const String& subtitle) const {
    (void)title;
    (void)subtitle;
}

void ThreatGuard::displaySection(const String& title) const {
    std::cout << title << "\n";
}

void ThreatGuard::displayStatus(const String& message, const String& style) const {
    (void)style;
    std::cout << message << "\n";
}

void ThreatGuard::printMenu(const String& title, const std::vector<String>& options, const String& subtitle) const {
    (void)subtitle;
    displayHeader(title);
    for (size_t i = 0; i < options.size(); ++i) {
        std::cout << (i + 1) << ". " << options[i] << "\n";
    }
    std::cout << "\n";
}

void ThreatGuard::displayPasswordRequirements() {
    displaySection("Password Requirements");
    std::cout << "  - Minimum 8 characters\n";
    std::cout << "  - At least one uppercase letter\n";
    std::cout << "  - At least one lowercase letter\n";
    std::cout << "  - At least one digit\n";
    std::cout << "  - At least one special character\n\n";
}

bool ThreatGuard::isUserExists(const String& username) {
    return findUser(username) != nullptr;
}

User* ThreatGuard::findUser(const String& username) {
    for (auto& user : users) {
        if (user.getUsername() == username) {
            return &user;
        }
    }
    return nullptr;
}

bool ThreatGuard::isPasswordValid(const String& password) {
    return PasswordModule::validatePassword(password);
}

User* ThreatGuard::getCurrentUser() {
    if (currentUsername.empty()) {
        return nullptr;
    }
    return findUser(currentUsername);
}

bool ThreatGuard::registerUser(const String& username, const String& password) {
    // Check if username already exists
    if (isUserExists(username)) {
        std::cout << "Username already exists!\n";
        return false;
    }

    // Validate password
    if (!isPasswordValid(password)) {
        std::cout << "Password does not meet requirements!\n";
        displayPasswordRequirements();
        return false;
    }

    // Hash password and create user
    std::string hashedPassword = PasswordModule::hashPassword(password);
    User newUser(username, hashedPassword);
    users.push_back(newUser);

    // Log registration
    logger.logRegistration(username);

    std::cout << "User registered successfully!\n";
    return true;
}

bool ThreatGuard::loginUser(const String& username, const String& password) {
    User* user = findUser(username);

    if (!user) {
        std::cout << "User not found!\n";
        logger.logLogin(username, false);
        return false;
    }

    // Check if account is locked
    if (user->isAccountLocked()) {
        std::cout << "Account is locked! Contact administrator.\n";
        return false;
    }

    // Verify password
    if (PasswordModule::verifyPassword(password, user->getHashedPassword())) {
        // Successful login
        user->resetFailedAttempts();
        currentUsername = username;
        logger.logLogin(username, true);
        std::cout << "Login successful! Welcome, " << username << "!\n";
        std::cout << std::endl;
        return true;
    } else {
        // Failed login
        user->incrementFailedAttempts();
        int attempts = user->getFailedAttempts();
        logger.logFailedAttempt(username, attempts);
        logger.logLogin(username, false);

        std::cout << "Invalid password! Attempt " << attempts << " of 3\n";

        if (user->isAccountLocked()) {
            logger.logAccountLocked(username);
            logger.logBruteForceAlert(username);
            std::cout << "*** ACCOUNT LOCKED DUE TO MULTIPLE FAILED ATTEMPTS! ***\n";
            std::cout << "*** BRUTE FORCE ATTACK DETECTED! ***\n";
        }

        return false;
    }
}

void ThreatGuard::logoutUser() {
    if (!currentUsername.empty()) {
        std::cout << "Logging out user: " << currentUsername << "\n";
        currentUsername.clear();
    }
}

void ThreatGuard::changePassword(const String& username, const String& oldPassword, const String& newPassword) {
    User* user = findUser(username);
    if (!user) {
        std::cout << "User not found!\n";
        return;
    }

    // Verify old password
    if (!PasswordModule::verifyPassword(oldPassword, user->getHashedPassword())) {
        std::cout << "Incorrect current password!\n";
        return;
    }

    // Validate new password
    if (!isPasswordValid(newPassword)) {
        std::cout << "New password does not meet requirements!\n";
        displayPasswordRequirements();
        return;
    }

    // Update password
    std::string newHashedPassword = PasswordModule::hashPassword(newPassword);
    user->setHashedPassword(newHashedPassword);
    logger.logPasswordChange(username);
    std::cout << "Password changed successfully!\n";
}

void ThreatGuard::viewUserLogs(const String& username) {
    logger.displayUserLogs(username);
}

void ThreatGuard::viewAllLogs() {
    logger.displayAllLogs();
}

void ThreatGuard::viewAllUsers() {
    std::cout << "\n========== ALL USERS ==========\n";
    if (users.empty()) {
        std::cout << "No users registered.\n";
        return;
    }

    std::cout << "Username\tStatus\t\tFailed Attempts\n";
    std::cout << "----------------------------------------\n";
    for (const auto& user : users) {
        std::cout << user.getUsername() << "\t\t"
                  << (user.isAccountLocked() ? "LOCKED" : "ACTIVE") << "\t"
                  << user.getFailedAttempts() << "\n";
    }
}

void ThreatGuard::unlockUserAccount(const String& username) {
    User* user = findUser(username);
    if (!user) {
        std::cout << "User not found!\n";
        return;
    }

    if (!user->isAccountLocked()) {
        std::cout << "Account is not locked.\n";
        return;
    }

    user->unlockAccount();
    logger.logAccountUnlocked(username);
    std::cout << "Account unlocked successfully!\n";
}

void ThreatGuard::showUserDashboard() {
    User* currentUser = getCurrentUser();
    if (!currentUser) {
        displayStatus("No active session found.", "ERROR");
        waitForEnter();
        return;
    }

    int choice;
    do {
        std::vector<String> options = {
            "View My Logs",
            "Change Password",
            "View System Logs",
            "Logout"
        };
        printMenu("USER DASHBOARD", options, "");
        std::cout << "Logged in as: " << currentUser->getUsername() << "\n";
        choice = readIntChoice("Select an option: ");

        switch (choice) {
            case 1:
                displayStatus("Loading your activity log...", "INFO");
                viewUserLogs(currentUser->getUsername());
                waitForEnter();
                break;
            case 2: {
                String oldPass, newPass;
                oldPass = readTextInput("Enter current password: ");
                newPass = readTextInput("Enter new password: ");
                changePassword(currentUser->getUsername(), oldPass, newPass);
                waitForEnter();
                break;
            }
            case 3:
                displayStatus("Loading system activity...", "INFO");
                viewAllLogs();
                waitForEnter();
                break;
            case 4:
                logoutUser();
                displayStatus("You have been logged out successfully.", "SUCCESS");
                waitForEnter();
                return;
            default:
                displayStatus("That choice is not valid. Please try again.", "WARN");
                waitForEnter();
        }
    } while (choice != 4);
}

void ThreatGuard::showAdminMenu() {
    User* currentUser = getCurrentUser();
    if (!currentUser || currentUser->getUsername() != "admin") {
        displayStatus("Access denied. Administrative privileges are required.", "ERROR");
        waitForEnter();
        return;
    }

    int choice;
    do {
        std::vector<String> options = {
            "View All Users",
            "View All Logs",
            "Unlock User Account",
            "View User Logs",
            "Logout"
        };
        printMenu("ADMIN DASHBOARD", options, "");
        choice = readIntChoice("Select an option: ");

        switch (choice) {
            case 1:
                displayStatus("Listing registered users...", "INFO");
                viewAllUsers();
                waitForEnter();
                break;
            case 2:
                displayStatus("Loading security events...", "INFO");
                viewAllLogs();
                waitForEnter();
                break;
            case 3: {
                String username;
                username = readTextInput("Enter username to unlock: ");
                unlockUserAccount(username);
                waitForEnter();
                break;
            }
            case 4: {
                String username;
                username = readTextInput("Enter username: ");
                viewUserLogs(username);
                waitForEnter();
                break;
            }
            case 5:
                logoutUser();
                displayStatus("Admin session closed successfully.", "SUCCESS");
                waitForEnter();
                return;
            default:
                displayStatus("That choice is not valid. Please try again.", "WARN");
                waitForEnter();
        }
    } while (choice != 5);
}

void ThreatGuard::showMainMenu() {
    int choice;
    do {
        std::vector<String> options = {
            "Register",
            "Login",
            "Admin Login",
            "View System Logs",
            "Exit"
        };
        printMenu("MAIN MENU", options, "");
        choice = readIntChoice("Select an option: ");

        switch (choice) {
            case 1: {
                String username, password;
                username = readTextInput("Enter username: ");
                password = readTextInput("Enter password: ");
                registerUser(username, password);
                waitForEnter();
                break;
            }
            case 2: {
                String username, password;
                username = readTextInput("Enter username: ");
                password = readTextInput("Enter password: ");
                if (loginUser(username, password)) {
                    showUserDashboard();
                }
                waitForEnter();
                break;
            }
            case 3: {
                String username, password;
                username = readTextInput("Enter admin username: ");
                password = readTextInput("Enter admin password: ");
                if (username == "admin" && loginUser(username, password)) {
                    showAdminMenu();
                }
                waitForEnter();
                break;
            }
            case 4:
                displayStatus("Displaying recent security events...", "INFO");
                viewAllLogs();
                waitForEnter();
                break;
            case 5:
                displayStatus("Thank you for using ThreatGuard.", "SUCCESS");
                exit(0);
            default:
                displayStatus("That choice is not valid. Please try again.", "WARN");
                waitForEnter();
        }
    } while (choice != 5);
}
