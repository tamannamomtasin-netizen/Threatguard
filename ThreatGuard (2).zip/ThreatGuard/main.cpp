#include "ThreatGuard.h"
#include <iostream>

int main() {
    std::cout << "\n====================================================\n";
    std::cout << "      THREATGUARD - CYBERSECURITY PLATFORM\n";
    std::cout << "====================================================\n";
    std::cout << "  Modern secure authentication and intrusion monitoring\n";
    std::cout << "====================================================\n";
    std::cout << "\nStarting ThreatGuard...\n";

    ThreatGuard system;
    system.showMainMenu();

    return 0;
}
